from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import requests
import json

default_args = {
    'owner': 'faiz',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def extract_data():
    """Extract data from source"""
    print("Extracting data from source...")
    # Add your data extraction logic here
    data = {"status": "extracted", "timestamp": str(datetime.now())}
    return data

def transform_data(**context):
    """Transform the extracted data"""
    print("Transforming data...")
    # Add your transformation logic here
    ti = context['ti']
    raw_data = ti.xcom_pull(task_ids='extract_task')
    transformed = {"status": "transformed", "source": raw_data}
    return transformed

def load_to_minio(**context):
    """Load transformed data into MinIO (Data Lake Storage)"""
    print("Loading data into MinIO...")
    # Add your MinIO upload logic here using boto3
    # Example:
    # import boto3
    # s3 = boto3.client('s3', endpoint_url='http://minio:9000',
    #                   aws_access_key_id='admin',
    #                   aws_secret_access_key='password')
    # s3.put_object(Bucket='datalake', Key='data.json', Body=json.dumps(data))
    print("Data successfully loaded to MinIO!")

with DAG(
    'datalake_pipeline',
    default_args=default_args,
    description='Data Lake ETL Pipeline',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=['datalake', 'etl'],
) as dag:

    extract_task = PythonOperator(
        task_id='extract_task',
        python_callable=extract_data,
    )

    transform_task = PythonOperator(
        task_id='transform_task',
        python_callable=transform_data,
        provide_context=True,
    )

    load_task = PythonOperator(
        task_id='load_task',
        python_callable=load_to_minio,
        provide_context=True,
    )

    # Pipeline order: Extract → Transform → Load
    extract_task >> transform_task >> load_task
